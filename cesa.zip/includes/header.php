<!DOCTYPE html>
<html lang="zxx">

<head>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="keywords" content="CESA 2021 2k21 AISSMS IOIT" />
    <meta name="description" content="CESA 2k21" />
    <meta name="author" content="" />

    <!-- Title  -->
    <title>CESA | IOIT</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="img/favicon.png" />

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:200,300,400,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Dosis:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:300,400,500,600,700" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Plugins -->
    <link rel="stylesheet" href="css/plugins.css" />
    <link rel="stylesheet" href="css/all.min.css" />

    <!-- Core Style Css -->
    <link rel="stylesheet" href="css/style.css" />

</head>
